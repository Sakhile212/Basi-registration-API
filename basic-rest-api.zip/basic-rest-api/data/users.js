let users = [];
let idCounter = 1;

module.exports = {
  users,
  idCounter
};
