const API_URL = "http://localhost:3000/api/users";

const userForm = document.getElementById("user-form");
const userList = document.getElementById("user-list");

// Fetch users
async function fetchUsers() {
  const res = await fetch(API_URL);
  const users = await res.json();

  userList.innerHTML = "";

  users.forEach(user => {
    const li = document.createElement("li");

    li.innerHTML = `
      <span>
        <strong>${user.name}</strong> (${user.email}) - Age: ${user.age}
      </span>
      <div class="actions">
        <button onclick="editUser(${user.id})">Edit</button>
        <button onclick="deleteUser(${user.id})">Delete</button>
      </div>
    `;

    userList.appendChild(li);
  });
}

// Create user
userForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const age = document.getElementById("age").value;

  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, age })
  });

  userForm.reset();
  fetchUsers();
});

// Delete user
async function deleteUser(id) {
  await fetch(`${API_URL}/${id}`, {
    method: "DELETE"
  });

  fetchUsers();
}

// Edit user
async function editUser(id) {
  const name = prompt("Enter new name:");
  const email = prompt("Enter new email:");
  const age = prompt("Enter new age:");

  if (!name || !email || !age) return;

  await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, age })
  });

  fetchUsers();
}

// Initial load
fetchUsers();
